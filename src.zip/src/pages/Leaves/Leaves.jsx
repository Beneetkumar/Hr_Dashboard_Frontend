import React, { useEffect, useState } from "react";
import "./Leaves.css";
import AddLeave from "./AddLeave";

const API = "http://localhost:5000";

export default function Leaves() {
  const [leaves, setLeaves] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [showAdd, setShowAdd] = useState(false);
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("");

  const load = () => {
    setLoading(true);
    setError("");
    try {
      const url = new URL(`${API}/api/leaves`);
      if (search.trim()) url.searchParams.set("search", search.trim());
      if (status) url.searchParams.set("status", status);

      fetch(url.toString(), { credentials: "include" })
        .then((r) => {
          if (!r.ok) throw new Error("Failed to fetch leaves");
          return r.json();
        })
        .then((d) => {
          setLeaves(Array.isArray(d.items) ? d.items : d);
          setLoading(false);
        })
        .catch((e) => {
          setError(e.message);
          setLoading(false);
        });
    } catch (err) {
      setError("Invalid filter request");
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const onFilterSubmit = (e) => {
    e.preventDefault();
    load();
  };

  return (
    <div className="leaves-page">
      <h1 className="leaves-title">📅 Leaves</h1>

      {/* Filters */}
      <form className="filters" onSubmit={onFilterSubmit}>
        <input
          type="text"
          placeholder="Search by employee name"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="search-input"
        />
        <select
          value={status}
          onChange={(e) => setStatus(e.target.value)}
          className="select"
        >
          <option value="">Any Status</option>
          <option value="Pending">Pending</option>
          <option value="Approved">Approved</option>
          <option value="Rejected">Rejected</option>
        </select>
        <button type="submit" className="btn">Apply</button>
      </form>

      {/* Add Leave Button */}
      <button
        className="btn btn-primary"
        onClick={() => setShowAdd((s) => !s)}
      >
        {showAdd ? "Close" : "Add Leave"}
      </button>

      {/* Add Leave Modal */}
      {showAdd && (
        <AddLeave onCreated={() => load()} onClose={() => setShowAdd(false)} />
      )}

      {/* Loading/Error States */}
      {loading && <p className="loading-text">Loading leaves...</p>}
      {error && <p className="error-text">{error}</p>}

      {/* Leaves List */}
      {!loading && !error && (
        <>
          {leaves.length === 0 ? (
            <p className="empty-state">No leave records found.</p>
          ) : (
            <div className="leaves-grid">
              {leaves.map((leave) => (
                <div className="leave-card" key={leave._id}>
                  <h3>{leave.employeeName}</h3>
                  <p><strong>Type:</strong> {leave.type}</p>
                  <p>
                    <strong>Status:</strong>{" "}
                    <span className={`status-badge ${leave.status?.toLowerCase()}`}>
                      {leave.status}
                    </span>
                  </p>
                  <p>
                    <strong>From:</strong> {new Date(leave.startDate).toLocaleDateString()}<br />
                    <strong>To:</strong> {new Date(leave.endDate).toLocaleDateString()}
                  </p>
                  {leave.documentUrl && (
                    <p>
                      <strong>Doc:</strong>{" "}
                      <a
                        href={`${API}${leave.documentUrl}`}
                        target="_blank"
                        rel="noreferrer"
                      >
                        View
                      </a>
                    </p>
                  )}
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
