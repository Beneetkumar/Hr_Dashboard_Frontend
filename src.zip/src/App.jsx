import React from "react";
import { Routes, Route, Link, Navigate } from "react-router-dom";
import Login from "./pages/Login/Login";
import Dashboard from "./pages/Dashboard/Dashboard";
import Candidates from "./pages/Candidates/Candidates";
import Employees from "./pages/Employees/Employees";
import Attendance from "./pages/Attendance/Attendance";
import Leaves from "./pages/Leaves/Leaves";
import Register from "./pages/Register/Register";
import { useAuth } from "./hooks/useAuth";
import "./App.css"; // ✅ new navbar styles

export default function App() {
  const { user, logout } = useAuth();

  return (
    <div>
      {/* Navbar */}
      <header className="navbar">
        <div className="nav-container">
          <div className="logo">
            <Link to="/">HRMS</Link>
          </div>

          {user && (
            <nav className="nav-links">
              <Link to="/">Dashboard</Link>
              <Link to="/candidates">Candidates</Link>
              <Link to="/employees">Employees</Link>
              <Link to="/attendance">Attendance</Link>
              <Link to="/leaves">Leaves</Link>
            </nav>
          )}

          <div className="nav-actions">
            {user ? (
              <button onClick={logout} className="btn logout-btn">
                Logout
              </button>
            ) : (
              <>
                <Link to="/login" className="btn btn-primary">Login</Link>
                <Link to="/register" className="btn btn-secondary">Register</Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Page Content */}
      <main className="main-container">
        <Routes>
          <Route path="/" element={user ? <Dashboard /> : <Navigate to="/login" />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route path="/candidates" element={user ? <Candidates /> : <Navigate to="/login" />} />
          <Route path="/employees" element={user ? <Employees /> : <Navigate to="/login" />} />
          <Route path="/attendance" element={user ? <Attendance /> : <Navigate to="/login" />} />
          <Route path="/leaves" element={user ? <Leaves /> : <Navigate to="/login" />} />
        </Routes>
      </main>
    </div>
  );
}
